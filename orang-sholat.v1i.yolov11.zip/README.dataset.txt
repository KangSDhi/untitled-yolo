# orang-sholat > 2025-03-20 10:03pm
https://universe.roboflow.com/dogvscat-ugups/orang-sholat

Provided by a Roboflow user
License: CC BY 4.0

